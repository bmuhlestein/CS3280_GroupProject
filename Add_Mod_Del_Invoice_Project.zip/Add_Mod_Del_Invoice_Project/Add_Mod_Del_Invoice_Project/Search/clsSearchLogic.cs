﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Add_Mod_Del_Invoice_Project.Search
{
    class clsSearchLogic
    {

        /* ???
         * For example, if a property is set in the Search screen window
         * with the selected Invoice ID, then the comment will explain how
         * the variable is set and the Main screen may access this data via a property
         */


        /*
         * Things to do:
            *Pull info from user input
            *Search the database for specific invoice num
            *Display grid 
            *Have user select specific invoice 
            *Pass info to main screen 
         */


        /* in example programs check out the grid stuff 17-21*/



    }
}
